# Streamlit Report App

App per generare grafici, esportare PDF, caricare su Google Drive e inviare via email i dati da file Excel.

## Funzionalità
- Caricamento file Excel
- Visualizzazione e modifica interattiva dei dati
- Esportazione PDF
- Upload su Google Drive
- Invio email automatico
