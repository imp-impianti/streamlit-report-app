import streamlit as st

st.set_page_config(layout="wide", page_title="Report App")

st.title("📊 Streamlit Report App")
st.write("Benvenuto nell'applicazione per la generazione dei report da file Excel.")

# Placeholder per caricamento, visualizzazione, ed esportazione
