# Modulo per invio email con allegato
# Da completare con SMTP o Gmail API
